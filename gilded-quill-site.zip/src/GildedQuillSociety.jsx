import React from "react";

export default function GildedQuillSociety() {
  return (
    <div className="min-h-screen bg-[#fdfaf6] text-[#3a2f2b] font-serif p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-wider">The Gilded Quill Society</h1>
        <p className="text-lg mt-2 italic">Where words wear velvet and ink breathes gold</p>
      </header>

      <footer className="text-center text-xs text-muted-foreground mt-12">
        © 2025 The Gilded Quill Society. All rights reserved.
      </footer>
    </div>
  );
}