import React from 'react'
import ReactDOM from 'react-dom/client'
import GildedQuillSociety from './GildedQuillSociety'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GildedQuillSociety />
  </React.StrictMode>,
)